<template>
  <flow-scheme-dtl :is-edit='true'></flow-scheme-dtl>
</template>

<script>
import flowSchemeDtl from './components/flowSchemeDtl'

export default {
  name: 'editFlowscheme',
  components: { flowSchemeDtl },
  mounted(){
  }
}
</script>

