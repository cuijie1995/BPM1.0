<template>
  <flow-scheme-dtl :is-edit='false'></flow-scheme-dtl>
</template>

<script>
import flowSchemeDtl from './components/flowSchemeDtl'

export default {
  name: 'addFlowscheme',
  components: { flowSchemeDtl },
   mounted(){
  }
}
</script>

