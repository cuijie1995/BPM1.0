
export default {

  copyObj(obj) {
    return JSON.parse(JSON.stringify(obj))
  }
}
