const state = {
    user: {},
    routers:[]
}


export default state;