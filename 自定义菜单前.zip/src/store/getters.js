const getters = {
    user(state){
        return state.user
    },

    routers(state){
        return state.routers
    }
}

export default getters